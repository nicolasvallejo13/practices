import java.util.Scanner;

public class Main 
{
	public static void main(String[] args)
	{
		Juego juego1 = new Juego();
		juego1.crearTablero();
		juego1.crearElementos();
		juego1.Jugar();
		
	}	
}
